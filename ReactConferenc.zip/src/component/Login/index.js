import React, { useState, useEffect } from 'react';
import { Button, Card, CardHeader, CardBody, CardFooter, CardTitle, FormGroup, Form, Input, Row, Col } from "reactstrap";
import axios from 'axios'
import Cryptr from 'cryptr';
import { ToastContainer } from 'react-toastify';
import { GITHUBCREDENTIALS } from '../../const/urls'
import { login } from '../../service/service';
import toast from '../common/toast';
import './login.css';


function LoginScreen(props) {
  const { history, Login } = props;
  const [emailId, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [disable, disableEmail] = useState(false);
  const [error, setError] = useState({ email: '', password: '' });
  const cryptr = new Cryptr('myTotalySecretKey');



  useEffect(() => {
    const url = window.location.href;
    const hasCode = url.includes("?code=");

    // If Github API returns the code parameter
    if (hasCode) {
      const newUrl = url.split("?code=");
      window.history.pushState({}, null, newUrl[0]);

      const requestData = {
        client_id: GITHUBCREDENTIALS.client_id,
        redirect_uri: GITHUBCREDENTIALS.redirect_uri,
        client_secret: GITHUBCREDENTIALS.client_secret,
        code: newUrl[1]
      };

      // Use code parameter and other parameters to make POST request to proxy_server
      axios.post(`/login/oauth/access_token`, requestData).then(res => {
        debugger
        if (res.status == 200) {
          toast("Login Successfully", "success");
          history.push('/admin/dashboard');
        } else {
          toast("Login attempt failed", "error")
        }
      })
    }
  }, []);


  return (
    <>
      <div className="content container">
        <Row className="justify-content-center">

          <Col md="4" className="login-container">
            <div className="login-image">
              <img
                alt="..."
                src={require("../../assets/img/large size-05.png")}
              />
            </div>
            <Card className="card-user">

              <CardBody >
                <Form>

                  <a
                    className="login-link"
                    href="https://github.com/login/oauth/authorize?scope=user&client_id=3c12695db036c05f2356&redirect_uri=http://localhost:3000/login"

                  >Login With Github</a>


                </Form>

              </CardBody>
            </Card>
          </Col>
          <ToastContainer />
        </Row> </div >
    </>
  );
}

export default LoginScreen;
