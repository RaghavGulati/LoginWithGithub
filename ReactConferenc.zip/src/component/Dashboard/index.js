import React, { useState, useEffect } from 'react';
import axios from 'axios'
import { ToastContainer } from 'react-toastify';
import toast from '../common/toast'
import './dashboard.css';
import { Card, CardHeader, CardBody, CardTitle, Row, Col, Table, } from "reactstrap";

export default function DashBoard(props) {
  const { history } = props;
  const [data, setData] = useState([]);
  const [hittingapi, setstatus] = useState(true);

  useEffect(() => {
    debugger
    axios.get(`/repositories`).then(res => {
      debugger
      if (res.status == 200) {
        setData(res.data)
      } else {
        toast("Error while getting repository", "error")
      }
    })

  }, []);

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardHeader>
              <CardTitle tag="h4">Top Repositories</CardTitle>
            </CardHeader>
            <CardBody>
              <Table>
                <tbody>
                  <tr>
                    <td>Name</td>
                    <td>Description</td>
                    <td>Author</td>
                  </tr>
                  {data && data.length > 0 ?
                    data.map((item, index) => {
                      return (

                        <tr id={index} key={index}>
                          <td>{item.name}</td>
                          <td>{item.description}</td>
                          <td>{item.author}</td>
                        </tr>
                      )
                    }) : hittingapi ? <tr>
                      <td></td>
                      <td>Getting the repositories</td>
                      <td></td>
                    </tr> :
                      <tr>
                        <td></td>
                        <td>No Meetings Found</td>
                        <td></td>
                      </tr>
                  }
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
      <div>
        <ToastContainer />
      </div>
    </div>
  );

}