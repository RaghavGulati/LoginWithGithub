import React from 'react';
import SideNav from 'react-simple-sidenav';

const SideNavBar = (props) => {
    const { isOpen, setShowNav, history, navData } = props;
    const navItems = navData.map(item => {
        return (
            <span target={item.url} onClick={() => history.push(item.url)}>
                {item.name}
            </span>
        )
    });
    const title = 'Hello octo';

    return (
        <SideNav
            showNav={isOpen}
            onHideNav={setShowNav}
            title={title}
            items={navItems}
            titleStyle={{ backgroundColor: '#4CAF50' }}
            itemStyle={{ backgroundColor: '#fff' }}
            itemHoverStyle={{ backgroundColor: '#CDDC39' }} />

    );
};

export default SideNavBar;