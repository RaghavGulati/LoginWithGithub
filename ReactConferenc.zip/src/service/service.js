import axios from 'axios'
import { GITHUBCREDENTIALS } from '../const/urls'
import toast from '../component/common/toast'


const login = (githubcode, history) => async () => {
  debugger
  const requestData = {
    client_id: GITHUBCREDENTIALS.client_id,
    redirect_uri: GITHUBCREDENTIALS.redirect_uri,
    client_secret: GITHUBCREDENTIALS.client_secret,
    code: githubcode
  };

  axios.post(`/login/oauth/access_token`, requestData).then(res => {
    debugger
    if (res.status == 200) {
      toast("Login Successfully", "success");
      history.push('/admin/dashboard');
    } else {
      toast("Login attempt failed", "error")
    }
  })
}

const getRepos = () => async () => {
  axios.post(`/repositories`).then(res => {
    debugger
    if (res.status == 200) {

    } else {

    }
  })
}



export {
  login,
  getRepos
};