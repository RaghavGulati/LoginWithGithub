const jwt = require('jsonwebtoken');

const validateToken = (token, history) => {
    jwt.verify(token, 'secret', function (err, decoded) {
        if (err != null) {
            history.push('/');
        }
    });
}
const setInLocalStorage = (key, value) => {
    localStorage.setItem(key, JSON.stringify(value));
}

const getfromLocalStorage = (key) => {
    return JSON.parse(localStorage.getItem(key));
}
export {
    validateToken,
    setInLocalStorage,
    getfromLocalStorage
};