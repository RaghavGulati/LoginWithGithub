import { Map } from 'immutable';
import { getfromLocalStorage } from '../utils/common';
import { USER_DETAILS } from '../const/urls';
const initialState = new Map({
    userDetail: '',
    jwtToken: ''
})

const userDetails = (state = initialState, action) => {
    switch (action.type) {
        case USER_DETAILS:
            return state.set('userDetail', action.payload);
        default:
            return state;
    }
}
export default userDetails;
